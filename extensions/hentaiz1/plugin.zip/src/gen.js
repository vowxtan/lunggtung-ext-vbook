load('config.js');

function execute(url, page) {
    if (!page) page = '1';
    var fetchUrl = url;
    
    // Nếu không phải trang 1, chèn query parameter page
    if (page !== '1') {
        if (fetchUrl.indexOf('?') > 0) {
            fetchUrl += '&page=' + page;
        } else {
            fetchUrl += '?page=' + page;
        }
    }

    var b = Engine.newBrowser();
    var doc = null;
    try {
        b.setUserAgent(UserAgent.chrome());
        b.launchAsync(fetchUrl);

        // Chờ SvelteKit render Client-side JS
        for (var j = 0; j < 10; j++) {
            sleep(750);
            doc = b.html();
            if (doc && doc.select('a[href*="/watch/"]').size() > 0) break;
        }
    } finally {
        b.close();
    }

    if (doc && doc.select('a[href*="/watch/"]').size() > 0) {
        var list = parseCards(doc);
        
        // Nếu số lượng card lấy được >= 12, giả định có trang tiếp theo
        var hasNext = list.length >= 12;
        var next = hasNext ? (parseInt(page) + 1).toString() : null;

        return Response.success(list, next);
    }
    
    return Response.error("Không thể tải danh sách phim từ: " + fetchUrl);
}
